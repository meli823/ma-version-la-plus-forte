MA VERSION LA PLUS FORTE — VERSION WEB

Cette version est prévue pour être publiée sur une adresse HTTPS (par exemple GitHub Pages).
Il ne faut pas ouvrir index.html depuis le dossier Téléchargements sur Android : dans ce cas l'adresse commence par content:// et les vidéos distantes peuvent être bloquées.

CONTENU
- index.html : l'application
- Les vidéos sont appelées en HTTPS et restent dans le lecteur de l'application.

MISE EN LIGNE RAPIDE AVEC GITHUB PAGES
1. Créer un compte GitHub si nécessaire.
2. Créer un nouveau dépôt (repository), par exemple ma-version-la-plus-forte.
3. Ajouter index.html à la racine du dépôt.
4. Aller dans Settings > Pages.
5. Choisir la publication depuis la branche principale (main), dossier /root.
6. Enregistrer puis attendre la publication.
7. Ouvrir l'adresse https://VOTRE-NOM.github.io/ma-version-la-plus-forte/
8. Sur Android, Chrome > menu ⋮ > Ajouter à l'écran d'accueil.

IMPORTANT
GitHub Pages est un hébergement public. L'application ne contient pas de données personnelles dans le fichier ; les données de suivi enregistrées par l'application restent dans le stockage du navigateur du téléphone.
